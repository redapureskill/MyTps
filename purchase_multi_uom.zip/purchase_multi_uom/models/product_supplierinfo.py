from odoo import api, fields, models, _
from odoo.exceptions import UserError
class SupplierInfo(models.Model):
    _inherit = "product.supplierinfo"

    def _domain_product_id(self):
         
        dom = "[('id', 'in', {0})]"
        
        domain = f"{dom.format(self.product_tmpl_id.purchase_uom_ids.ids)}"
        # raise UserError(str(domain))
        return domain

    uom_ids = fields.Many2many(related="product_tmpl_id.purchase_uom_ids")
    product_uom = fields.Many2one('uom.uom', 'PO UOM',store=True,related=False)
