
from odoo import api, fields, models, _
class ProductTemplate(models.Model):
    _name = 'product.template'
    _inherit = 'product.template'


    purchase_uom_ids = fields.Many2many("uom.uom",string="Purchase UOMs")